package arduinoswitch;

import java.text.ParseException;

public class ArduinoSwitch {

    
    public static void main(String[] args) throws ParseException, Exception {
        Window Ventana = new Window();

        Ventana.setVisible(true);

    }

}
